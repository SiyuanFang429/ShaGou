function normal_list=Chongxin_Eliminate_normal2(normal_list,SD)
    [~,list_columns]=size(normal_list);
    for j=18:list_columns
        k=0;
        while 1
            k=k+1;
            x_normal=abs(cell2mat(normal_list(:,j))-mean(cell2mat(normal_list(:,j))))>SD*std(cell2mat(normal_list(:,j)));            
            if(x_normal==0)
                break;
            end
            normal_list(x_normal,:)=[];
            size(normal_list);
        end
    end
    %normal_list=[normal_list(:,2),normal_list(:,1),normal_list(:,3)];
end