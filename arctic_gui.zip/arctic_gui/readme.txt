Single_Data_Input_Mode.m, File_Input_Mode.fig, File_Input_Mode.m and Single_Data_Input_Mode are special software.
Tree_Bagger3.m is the program calculation process in the article.

The title of the manuscript: Big-Data Driven New Basalt tectonic discrimination Approach
by Siyuan Fang