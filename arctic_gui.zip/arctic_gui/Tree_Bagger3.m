%�ݼ�����������������ʡ�׼ȷ��
clear all
clc
warning off
[FileName,PathName]  = uigetfile({'*.xlsx';'*.xls'},'�������excel�ļ�'); 

if  isequal(FileName,'')%��ֹѡ����ļ���
	msgbox('no excel you selected');
else 
    [~,~, sum_raw] = xlsread([PathName,FileName]);  
end
[sum_row,sum_column]=size(sum_raw);
for cell_menber=sum_column-17:-1:6
    element_name{:,sum_column-cell_menber-16}=sum_raw(1,18:end);
    for k=18:cell_menber+17
        %initial_data=cell2mat(raw(18:end,:));
        %initial_data(:,k)=[];
        raw=sum_raw(1:end,:);
        raw(:,k)=[];
        disp(element_name{sum_column-cell_menber-16}(1,k-17));
        data=[];
        sum_Species=[];
        sum_testdata=[];
        sum_flwrClass=[];
        sum_lastdata=[];
        %����Ԥ����
        for i=1:3
            index_list{i}=find(cell2mat(raw(:,1))==i);
            sum_list{i}=raw(index_list{i},1:cell_menber+16);   
            sum_list_zhi{i}=raw(index_list{i},18:cell_menber+16); 
            sum_list{i}(any(isnan(cell2mat(sum_list_zhi{i})),2),:)=[];
            sum_list2{i}=Chongxin_Eliminate_normal2(sum_list{i});
            data=[data;sum_list2{i}];
            count_list{sum_column-cell_menber-16}(k-17,i)=size(find(cell2mat(data(:,1))==i),1);   
        end
        %������֤
        for index1=1:5
            Species=cell2mat(data(:,1));
            CvIndices = crossvalind('Kfold',Species,4);
            %4��
            for i=1:4
                disp([num2str(cell_menber),'-',num2str(k-17),'-',num2str(index1),'-',num2str(i)]);
                Test=data(CvIndices==i,:);
                Train=data(CvIndices~=i,:);

                P_train=cell2mat(Train(:,18:end));
                T_train=cell2mat(Train(:,1));

                P_test=cell2mat(Test(:,18:end));
                T_test=cell2mat(Test(:,1));
                K_test=Test(:,2:17);

                Mdl = TreeBagger(200,P_train,T_train,'OOBPrediction','On','Method','classification','OOBPredictorImportance','on','PredictorSelection','curvature');
                [flwrClass,scores,stdevs] = predict(Mdl,P_test);
                flwrClass=str2num(char(flwrClass));
                %�����������
                sum_Species=[sum_Species;T_test];
                sum_flwrClass=[sum_flwrClass;flwrClass];
                sum_testdata=[sum_testdata;K_test,num2cell(P_test)];
                sum_lastdata=[num2cell(sum_Species),num2cell(sum_flwrClass),sum_testdata];
                
                %������ȷ��
                for j=1:3
                    train_count(i,j)=length(find(T_train == j));
                    test_count(i,j)=length(find(T_test == j));
                    flwrClass_count(i,j)=length(find(flwrClass == j));
                    sum_count(i,j)=length(find(cell2mat(data(:,1)) == j));
                    test_sim(i,j)=length(find(flwrClass == j & T_test == j));
                    Accuracy_Rate(i,j)=test_sim(i,j)/test_count(i,j)*100;
                    Accuracy_Rate2(i,j)=test_sim(i,j)/flwrClass_count(i,j)*100;
                end   
            end
            xlswrite(['G:\���¼���\���»��ܵ�8��\��������\',num2str(cell_menber),'-',num2str(index1),'-',element_name{sum_column-cell_menber-16}{1,k-17},'��������','.xlsx'],sum_lastdata);
            mean_AccuracyRate(index1,:)=mean(Accuracy_Rate);
            mean_AccuracyRate2(index1,:)=mean(Accuracy_Rate2);
        end
        sum_AccuracyRate=mean(mean_AccuracyRate);
        sum_AccuracyRate2=mean(mean_AccuracyRate2);
        AccuracyRate_list{sum_column-cell_menber-16}(k-17,:)=sum_AccuracyRate;
        AccuracyRate_list2{sum_column-cell_menber-16}(k-17,:)=sum_AccuracyRate2;
        
        
        %��������
        figure;
        list_cm{sum_column-cell_menber-16,k-17} = confusionchart(sum_Species,sum_flwrClass);
        list_cm{sum_column-cell_menber-16,k-17}.RowSummary = 'row-normalized';
        list_cm{sum_column-cell_menber-16,k-17}.ColumnSummary = 'column-normalized';
        cm_array{sum_column-cell_menber-16,k-17}=list_cm{sum_column-cell_menber-16,k-17}.NormalizedValues;
        list_cm{sum_column-cell_menber-16,k-17}.Normalization = 'total-normalized';
        savefig(['G:\���¼���\���»��ܵ�8��\��������\', num2str(cell_menber),'-',element_name{sum_column-cell_menber-16}{1,k-17}]);
        saveas(gcf,['G:\���¼���\���»��ܵ�8��\��������ͼƬ\', num2str(cell_menber),'-',element_name{sum_column-cell_menber-16}{1,k-17},'.jpg']);
        close(gcf);
        

        %׼ȷ��
        figure;
        bar(sum_AccuracyRate,'stack');
        title('Predict Accuracy Rate');
        ylabel('Accuracy Rate');
        xlabel('tectonic type');
        h = gca;
        h.XTickLabelRotation = 45;
        ylim([0 100])
        set(gca,'Xtick',(1:1:3),'XtickLabel',{'Intra Continental','Convergent Margins','Oceanic'},'FontSize',8);
        h.TickLabelInterpreter = 'none';
        for i=1:length(sum_AccuracyRate)
            text(i,sum_AccuracyRate(i)+3,num2str(sum_AccuracyRate(i)),'VerticalAlignment','middle','HorizontalAlignment','center');
        end
        savefig(['G:\���¼���\���»��ܵ�8��\׼ȷ��\', num2str(cell_menber),'-',element_name{sum_column-cell_menber-16}{1,k-17}]);
        saveas(gcf,['G:\���¼���\���»��ܵ�8��\׼ȷ��ͼƬ\',num2str(cell_menber),'-',element_name{sum_column-cell_menber-16}{1,k-17},'.jpg']);
        close(gcf);
        
        %������
        figure;
        bar(sum_AccuracyRate2,'stack');
        title('Predict Confidence Rate');
        ylabel('Confidence Rate');
        xlabel('tectonic type');
        h = gca;
        h.XTickLabelRotation = 45;
        ylim([0 100])
        set(gca,'Xtick',(1:1:3),'XtickLabel',{'Intra Continental','Convergent Margins','Oceanic'},'FontSize',8);
        h.TickLabelInterpreter = 'none';
        for i=1:length(sum_AccuracyRate2)
            text(i,sum_AccuracyRate2(i)+3,num2str(sum_AccuracyRate2(i)),'VerticalAlignment','middle','HorizontalAlignment','center');
        end
        savefig(['G:\���¼���\���»��ܵ�8��\������\', num2str(cell_menber),'-',element_name{sum_column-cell_menber-16}{1,k-17}]);
        saveas(gcf,['G:\���¼���\���»��ܵ�8��\������ͼƬ\', num2str(cell_menber),'-',element_name{sum_column-cell_menber-16}{1,k-17},'.jpg']);
        close(gcf);
    end
    
    %max_score(sum_column-cell_menber)=find(AccuracyRate_list{sum_column-cell_menber}(:,3)==max(AccuracyRate_list{sum_column-cell_menber}(:,3)));
    %max_score(sum_column-cell_menber)=find((AccuracyRate_list{sum_column-cell_menber}(:,1)+AccuracyRate_list{sum_column-cell_menber}(:,2))...
    %                               ==max(AccuracyRate_list{sum_column-cell_menber}(:,1)+AccuracyRate_list{sum_column-cell_menber}(:,2)));
    max_score(sum_column-cell_menber-16)=find(sum(AccuracyRate_list{sum_column-cell_menber-16},2)==max(sum(AccuracyRate_list{sum_column-cell_menber-16},2)));

%     max_score(sum_column-cell_menber)=find((AccuracyRate_list2{sum_column-cell_menber}(:,1)+AccuracyRate_list2{sum_column-cell_menber}(:,2)+AccuracyRate_list2{sum_column-cell_menber}(:,3))...
%                                    ==max(AccuracyRate_list2{sum_column-cell_menber}(:,1)+AccuracyRate_list2{sum_column-cell_menber}(:,2)+AccuracyRate_list2{sum_column-cell_menber}(:,3)));
    sum_raw(:,max_score(sum_column-cell_menber-16)+17)=[];
end
for i=1:21
     Element_Name{i,:}=element_name{i}';
end

save(['G:\���¼���\���»��ܵ�8��\', 'di8ci'])


%view(Mdl.Trees{1},'Mode','graph')