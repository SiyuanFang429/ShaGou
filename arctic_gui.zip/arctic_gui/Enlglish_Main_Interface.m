function varargout = Enlglish_Main_Interface(varargin)
% ENLGLISH_MAIN_INTERFACE MATLAB code for Enlglish_Main_Interface.fig
%      ENLGLISH_MAIN_INTERFACE, by itself, creates a new ENLGLISH_MAIN_INTERFACE or raises the existing
%      singleton*.
%
%      H = ENLGLISH_MAIN_INTERFACE returns the handle to a new ENLGLISH_MAIN_INTERFACE or the handle to
%      the existing singleton*.
%
%      ENLGLISH_MAIN_INTERFACE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ENLGLISH_MAIN_INTERFACE.M with the given input arguments.
%
%      ENLGLISH_MAIN_INTERFACE('Property','Value',...) creates a new ENLGLISH_MAIN_INTERFACE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Enlglish_Main_Interface_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Enlglish_Main_Interface_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Enlglish_Main_Interface

% Last Modified by GUIDE v2.5 23-Sep-2019 20:01:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Enlglish_Main_Interface_OpeningFcn, ...
                   'gui_OutputFcn',  @Enlglish_Main_Interface_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Enlglish_Main_Interface is made visible.
function Enlglish_Main_Interface_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Enlglish_Main_Interface (see VARARGIN)

% Choose default command line output for Enlglish_Main_Interface
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Enlglish_Main_Interface wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Enlglish_Main_Interface_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function Menu_GN_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_GN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Menu_GNSM_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_GNSM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Menu_YSGZPB_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_YSGZPB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function Menu_WJSRPB_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_WJSRPB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Enlglish_File_Input_Discrimination;




% --------------------------------------------------------------------
function Menu_SJSRPB_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_SJSRPB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Enlglish_Data_Input_Discrimination;


% --------------------------------------------------------------------
function Menu_YJFYJX_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_YJFYJX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Enlglish_Distribution;
